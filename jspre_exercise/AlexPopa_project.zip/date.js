var date = new Date();
document.getElementById("data").innerHTML = "<p1>Today is: " + date + "</p1>";
