function toCelsius() {


  document.getElementById("grade").innerHTML = (5/9) * (document.getElementById("2").value - 32);
}
