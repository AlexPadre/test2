function myFunction() {
  if (document.getElementById('1').value % 2 == 0) {
    window.alert("Par");
   }
   else {
     window.alert("Impar");
   }

}
